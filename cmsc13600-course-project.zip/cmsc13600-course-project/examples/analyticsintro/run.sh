python manage.py runserver
